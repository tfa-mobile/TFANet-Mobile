//
//  ExamplePost.h
//  MKNetworkKitDemo
//
//  Created by Mugunth Kumar on 1/12/11.
//  Copyright (c) 2011 Steinlogic. All rights reserved.
//

@interface ExamplePost : MKNetworkEngine

-(MKNetworkOperation*) postDataToServer;
@end
