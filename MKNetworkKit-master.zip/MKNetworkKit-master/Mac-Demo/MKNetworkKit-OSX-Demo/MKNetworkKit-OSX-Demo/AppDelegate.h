//
//  AppDelegate.h
//  MKNetworkKit-OSX-Demo
//
//  Created by Mugunth Kumar on 7/12/11.
//  Copyright (c) 2011 Steinlogic. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
