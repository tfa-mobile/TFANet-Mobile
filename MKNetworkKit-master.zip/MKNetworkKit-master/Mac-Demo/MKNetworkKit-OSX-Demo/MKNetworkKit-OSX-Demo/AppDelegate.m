//
//  AppDelegate.m
//  MKNetworkKit-OSX-Demo
//
//  Created by Mugunth Kumar on 7/12/11.
//  Copyright (c) 2011 Steinlogic. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
